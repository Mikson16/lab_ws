VELOCIDAD_LINEAL = 0.2 #[m/s]
VELOCIDAD_ANGULAR = 1.0  #[rad/s]


### Parametros del reconocimiento por kinect
UMBRAL_DE_DETECCION = 0.7 # 0.5 #[m] Distancia desde la punta del robot
