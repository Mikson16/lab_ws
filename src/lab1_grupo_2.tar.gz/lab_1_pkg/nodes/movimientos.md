# i: Adelane

# j: Atrashhh

# a: Giro izq

# s: Giro der

# q: Avanza y gira izquierda

# w: Avanza y gira a la extrema derecha

# o: Detiene el robot

# p: Detiene key_manager